
public class MyGame {

	public static void main(String[] args) {
		new GameFrame();

	}

}
